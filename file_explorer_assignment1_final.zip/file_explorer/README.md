# Console-Based File Explorer

**Student Name:** Adyasha Muni 
**Course:** Capstone Project – Assignment 1 
**Language:** C++17 


## How to Run
1. Open terminal and go to project folder 
   cd ~/file_explorer
2. Compile:
   g++ -std=c++17 -o build/file_explorer src/main.cpp
3. Run:
   ./build/file_explorer
