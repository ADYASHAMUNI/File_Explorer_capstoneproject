#include <iostream>
#include <filesystem>
#include <string>
#include <chrono>
#include <iomanip>
#include <fstream>

namespace fs = std::filesystem;

// -------------- Function to show all menu options --------------
void show_menu() {
    std::cout << "\n=== Console File Explorer ===\n";
    std::cout << "1. List files\n";
    std::cout << "2. Change directory\n";
    std::cout << "3. Go up (parent)\n";
    std::cout << "4. Show file info\n";
    std::cout << "5. Create file / directory\n";
    std::cout << "6. Delete file / directory\n";
    std::cout << "7. Copy file\n";
    std::cout << "8. Move/Rename file\n";
    std::cout << "9. Search files (recursive)\n";
    std::cout << "10.View permissions\n";
    std::cout << "11.Change permissions\n";
    std::cout << "0. Quit\n";
    std::cout << "Choose an option: ";
}

// -------------- List directory contents --------------
void list_directory(const fs::path& p) {
    try {
        std::cout << "Listing: " << p << "\n";
        for (auto &entry : fs::directory_iterator(p)) {
            auto name = entry.path().filename().string();
            std::string type = entry.is_directory() ? "[D]" : "[F]";
            std::uintmax_t size = 0;
            if (entry.is_regular_file()) size = fs::file_size(entry.path());
            std::cout << type << " " << std::setw(10) << size << " bytes  " << name << "\n";
        }
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// -------------- Show info about one file --------------
void show_file_info(const fs::path& base) {
    std::string name;
    std::cout << "Enter file or directory name: ";
    std::getline(std::cin, name);
    fs::path p = base / name;

    try {
        if (!fs::exists(p)) { std::cout << "Not found!\n"; return; }

        std::cout << "\nPath: " << fs::canonical(p) << "\n";
        std::cout << "Type: " << (fs::is_directory(p) ? "Directory" : "File") << "\n";
        if (fs::is_regular_file(p))
            std::cout << "Size: " << fs::file_size(p) << " bytes\n";

        auto ftime = fs::last_write_time(p);
        auto sctp = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
            ftime - fs::file_time_type::clock::now() + std::chrono::system_clock::now());
        std::time_t cftime = std::chrono::system_clock::to_time_t(sctp);
        std::cout << "Last modified: " << std::put_time(std::localtime(&cftime), "%F %T") << "\n";

    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// -------------- Create file or directory --------------
void create_item(const fs::path& base) {
    std::string name;
    std::cout << "Enter name: ";
    std::getline(std::cin, name);
    std::cout << "Create (f)ile or (d)irectory? ";
    char type; std::cin >> type;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    fs::path p = base / name;
    if (fs::exists(p)) { std::cout << "Already exists!\n"; return; }

    try {
        if (type == 'f') {
            std::ofstream ofs(p.string());
            ofs.close();
            std::cout << "File created.\n";
        } else if (type == 'd') {
            fs::create_directory(p);
            std::cout << "Directory created.\n";
        } else {
            std::cout << "Invalid type.\n";
        }
    } catch (...) {
        std::cout << "Error creating item.\n";
    }
}

// -------------- Delete file or directory --------------
void delete_item(const fs::path& base) {
    std::string name;
    std::cout << "Enter name to delete: ";
    std::getline(std::cin, name);
    fs::path p = base / name;

    if (!fs::exists(p)) { std::cout << "Not found.\n"; return; }

    std::cout << "Are you sure you want to delete " << name << "? (y/n): ";
    char ans; std::cin >> ans;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (ans != 'y' && ans != 'Y') { std::cout << "Aborted.\n"; return; }

    try {
        if (fs::is_directory(p)) fs::remove_all(p);
        else fs::remove(p);
        std::cout << "Deleted successfully.\n";
    } catch (...) {
        std::cout << "Error deleting item.\n";
    }
}
// -------------- Copy File --------------
void copy_file_item(const fs::path& base) {
    std::string srcName, dstName;
    std::cout << "Enter source file name: ";
    std::getline(std::cin, srcName);
    std::cout << "Enter destination file name: ";
    std::getline(std::cin, dstName);

    fs::path src = base / srcName;
    fs::path dst = base / dstName;

    try {
        if (!fs::exists(src)) {
            std::cout << "Source file not found.\n";
            return;
        }
        fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
        std::cout << "Copied successfully to: " << dst << "\n";
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// -------------- Move or Rename File --------------
void move_or_rename_item(const fs::path& base) {
    std::string srcName, dstName;
    std::cout << "Enter current file name: ";
    std::getline(std::cin, srcName);
    std::cout << "Enter new name or destination: ";
    std::getline(std::cin, dstName);

    fs::path src = base / srcName;
    fs::path dst = base / dstName;

    try {
        if (!fs::exists(src)) {
            std::cout << "File not found.\n";
            return;
        }
        fs::rename(src, dst);
        std::cout << "Moved/Renamed successfully to: " << dst << "\n";
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}
// -------------- Search Files Recursively --------------
void search_files_recursive(const fs::path& base) {
    std::string query;
    std::cout << "Enter search keyword: ";
    std::getline(std::cin, query);

    bool found = false;
    try {
        for (auto& entry : fs::recursive_directory_iterator(base)) {
            auto name = entry.path().filename().string();
            if (name.find(query) != std::string::npos) {
                std::cout << entry.path() << "\n";
                found = true;
            }
        }
        if (!found) std::cout << "No matches found.\n";
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}
// -------------- View File Permissions --------------
std::string perms_to_string(fs::perms p) {
    std::string s;
    s += ((p & fs::perms::owner_read)  != fs::perms::none) ? "r" : "-";
    s += ((p & fs::perms::owner_write) != fs::perms::none) ? "w" : "-";
    s += ((p & fs::perms::owner_exec)  != fs::perms::none) ? "x" : "-";
    return s;
}

void view_permissions(const fs::path& base) {
    std::string name;
    std::cout << "Enter file or directory name: ";
    std::getline(std::cin, name);
    fs::path p = base / name;

    try {
        if (!fs::exists(p)) {
            std::cout << "Not found.\n";
            return;
        }
        auto st = fs::status(p).permissions();
        std::cout << "Owner Permissions: " << perms_to_string(st) << " (r=read, w=write, x=execute)\n";
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}
// -------------- Change File Permissions (Owner Only) --------------
void change_permissions(const fs::path& base) {
    std::string name;
    std::cout << "Enter file or directory name: ";
    std::getline(std::cin, name);
    fs::path p = base / name;

    try {
        if (!fs::exists(p)) {
            std::cout << "Not found.\n";
            return;
        }

        std::cout << "\nChoose an option:\n";
        std::cout << "1. Add read permission\n";
        std::cout << "2. Remove read permission\n";
        std::cout << "3. Add write permission\n";
        std::cout << "4. Remove write permission\n";
        std::cout << "5. Add execute permission\n";
        std::cout << "6. Remove execute permission\n";
        std::cout << "Enter choice: ";

        int choice;
        std::cin >> choice;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 1: fs::permissions(p, fs::perms::owner_read,  fs::perm_options::add); break;
            case 2: fs::permissions(p, fs::perms::owner_read,  fs::perm_options::remove); break;
            case 3: fs::permissions(p, fs::perms::owner_write, fs::perm_options::add); break;
            case 4: fs::permissions(p, fs::perms::owner_write, fs::perm_options::remove); break;
            case 5: fs::permissions(p, fs::perms::owner_exec,  fs::perm_options::add); break;
            case 6: fs::permissions(p, fs::perms::owner_exec,  fs::perm_options::remove); break;
            default: std::cout << "Invalid choice.\n"; return;
        }
        std::cout << "Permissions updated successfully.\n";
    } catch (const fs::filesystem_error& e) {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// -------------- Main Program Loop --------------
int main() {
    fs::path current = fs::current_path();

    while (true) {
        std::cout << "\nCurrent Directory: " << current << "\n";
        show_menu();

        int choice;
        if (!(std::cin >> choice)) break;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (choice == 0) break;
        else if (choice == 1) list_directory(current);
        else if (choice == 2) {
            std::string dir;
            std::cout << "Enter directory name: ";
            std::getline(std::cin, dir);
            fs::path next = current / dir;
            if (fs::exists(next) && fs::is_directory(next))
                current = fs::canonical(next);
            else
                std::cout << "Directory not found.\n";
        }
        else if (choice == 3) {
            if (current.has_parent_path()) current = current.parent_path();
        }
        else if (choice == 4) show_file_info(current);
        else if (choice == 5) create_item(current);
        else if (choice == 6) delete_item(current);
        else if (choice == 7) copy_file_item(current);
        else if (choice == 8) move_or_rename_item(current);
        else if (choice == 9) search_files_recursive(current);
        else if (choice == 10) view_permissions(current);
        else if (choice == 11) change_permissions(current);
        else std::cout << "Invalid option.\n";
    }

    std::cout << "Goodbye!\n";
    return 0;
}

